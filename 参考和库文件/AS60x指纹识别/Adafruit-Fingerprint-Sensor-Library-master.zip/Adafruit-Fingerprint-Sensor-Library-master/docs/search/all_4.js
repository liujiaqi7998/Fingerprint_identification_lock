var searchData=
[
  ['emptydatabase',['emptyDatabase',['../class_adafruit___fingerprint.html#a1f68560eee38714be3b57fa1d191d67a',1,'Adafruit_Fingerprint']]]
];
